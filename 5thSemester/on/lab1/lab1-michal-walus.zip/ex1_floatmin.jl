# Michał Waluś 279695

println("Float32 floatmin: ", floatmin(Float32))
println("Float32 floatmin (bit Representation): ", bitstring(floatmin(Float32)))

println("\nFloat64 floatmin: ", floatmin(Float64))
println("Float64 floatmin (bit Representation): ", bitstring(floatmin(Float64)))
