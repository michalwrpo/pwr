# Michał Waluś 279695

include("plots.jl")
using .myplot

# plot1()
# plot2()
plot3()