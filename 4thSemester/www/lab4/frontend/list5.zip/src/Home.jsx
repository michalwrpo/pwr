function Home() {
    return (
        <div style={{ padding: '2rem' }}>
            <h1>Welcome to Our Store!</h1>
            <p>
                Discover the best products at unbeatable prices. Browse our categories and find what you need today!
            </p>
        </div>
    );
}

export default Home;